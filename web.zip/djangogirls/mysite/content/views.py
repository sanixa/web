from django.shortcuts import render
from django.views.decorators import csrf
import content.modsecurity.func as mod
from content.models import ovs1,ovs2,ns1,ns2
# Create your views here.

def modsecurity(request):
    #status = mod.nginx()
    return render(request, 'modsecurity.html', {
        'nginx_status': str(mod.nginx()),
    })

def index(request):
    return render(request, 'index.html',{})
def mod_l(request):
    return render(request, 'mod_l.html',{
        'nginx_status': str(mod.nginx()),
        'mod_status': str(mod.nginx_modsecurity())
    })
def mod_m(request):
    ctx ={}
    if request.POST:
        rlt = mod.mod_custom_rule(request.POST['q'])
        ctx['rlt'] = "增加 " + request.POST['q'] + " " + rlt
    return render(request, "mod_m.html", ctx)

def mod_m_re(request):
    mod.restart_nginx()
    return render(request, 'mod_m_re.html',{})
def route(request):
    return render(request, 'route.html',{
        'aaa': str('456') + '<br>' + str('123')
    })
def route_config(request):
    if request.POST:
        ovs = ovs1.objects.all()
        ovs.delete()
        ovs1.objects.create(name=request.POST['ovs-name1'], port=request.POST['ovs-port-name1'], number=request.POST['openflow-port-number1'])
        ovs = ovs2.objects.all()
        ovs.delete()
        ovs2.objects.create(name=request.POST['ovs-name2'], port=request.POST['ovs-port-name2'], number=request.POST['openflow-port-number2'])
        ns = ns1.objects.all()
        ns.delete()
        ns1.objects.create(name=request.POST['ns-name1'], address=request.POST['ns-port-address1'])
        ns = ns2.objects.all()
        ns.delete()
        ns2.objects.create(name=request.POST['ns-name2'], address=request.POST['ns-port-address2'])
    return render(request, 'route_config.html',{})
def temp(request):
    return render(request, 'temp.html',{})

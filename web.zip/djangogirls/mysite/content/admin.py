from django.contrib import admin

from .models import *
# Register your models here.

admin.site.register(ovs1)
admin.site.register(ovs2)
admin.site.register(ns1)
admin.site.register(ns2)
